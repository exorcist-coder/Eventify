import { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import EventDetail from './pages/EventDetail';
import EventCreate from './pages/EventCreate';
import EventEdit from './pages/EventEdit';
import OrganizerDashboard from './pages/OrganizerDashboard';
import TicketPurchase from './pages/TicketPurchase';
import UserProfile from './pages/UserProfile';
import NotFound from './pages/NotFound';
import { AuthProvider } from './contexts/AuthContext';
import { EventsProvider } from './contexts/EventsContext';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate initial data loading
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1000);
    
    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-t-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-700">Loading Eventverse...</h2>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <AuthProvider>
        <EventsProvider>
          <div className="flex flex-col min-h-screen">
            <Navbar />
            <main className="flex-grow">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/events/:eventId" element={<EventDetail />} />
                <Route path="/events/create" element={<EventCreate />} />
                <Route path="/events/edit/:eventId" element={<EventEdit />} />
                <Route path="/dashboard" element={<OrganizerDashboard />} />
                <Route path="/tickets/:eventId" element={<TicketPurchase />} />
                <Route path="/profile" element={<UserProfile />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </EventsProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;