// API utilities to simulate backend requests

import { events, ticketTypes, users, tickets, orders, promoCodes } from './mockData';

// Helper to simulate API delay
const simulateDelay = (ms = 300) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to find an item by ID
const findById = (array, id) => array.find(item => item.id === id);

// Helper to get a deep clone of an object
const clone = (obj) => JSON.parse(JSON.stringify(obj));

// ----------------- Events API -----------------

// Get all events
export const fetchEvents = async () => {
  await simulateDelay();
  return clone(events);
};

// Get a single event by ID
export const fetchEvent = async (eventId) => {
  await simulateDelay();
  const event = findById(events, eventId);
  if (!event) {
    throw new Error(`Event with ID ${eventId} not found`);
  }
  return clone(event);
};

// Create a new event
export const createEvent = async (eventData) => {
  await simulateDelay();
  const newEvent = {
    id: `event-${Date.now()}`,
    ...eventData,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  events.push(newEvent);
  return clone(newEvent);
};

// Update an existing event
export const updateEvent = async (eventId, eventData) => {
  await simulateDelay();
  const eventIndex = events.findIndex(event => event.id === eventId);
  if (eventIndex === -1) {
    throw new Error(`Event with ID ${eventId} not found`);
  }
  
  const updatedEvent = {
    ...events[eventIndex],
    ...eventData,
    updatedAt: new Date().toISOString()
  };
  
  events[eventIndex] = updatedEvent;
  return clone(updatedEvent);
};

// Delete an event
export const deleteEvent = async (eventId) => {
  await simulateDelay();
  const eventIndex = events.findIndex(event => event.id === eventId);
  if (eventIndex === -1) {
    throw new Error(`Event with ID ${eventId} not found`);
  }
  events.splice(eventIndex, 1);
  return true;
};

// ----------------- Ticket Types API -----------------

// Get all ticket types for an event
export const fetchTicketTypes = async (eventId) => {
  await simulateDelay();
  const eventTickets = ticketTypes.filter(ticket => ticket.eventId === eventId);
  return clone(eventTickets);
};

// Create a ticket type
export const createTicketType = async (ticketData) => {
  await simulateDelay();
  const newTicket = {
    id: `ticket-${Date.now()}`,
    ...ticketData,
    quantitySold: 0,
  };
  ticketTypes.push(newTicket);
  return clone(newTicket);
};

// Update a ticket type
export const updateTicketType = async (ticketId, ticketData) => {
  await simulateDelay();
  const ticketIndex = ticketTypes.findIndex(ticket => ticket.id === ticketId);
  if (ticketIndex === -1) {
    throw new Error(`Ticket type with ID ${ticketId} not found`);
  }
  
  const updatedTicket = {
    ...ticketTypes[ticketIndex],
    ...ticketData
  };
  
  ticketTypes[ticketIndex] = updatedTicket;
  return clone(updatedTicket);
};

// Delete a ticket type
export const deleteTicketType = async (ticketId) => {
  await simulateDelay();
  const ticketIndex = ticketTypes.findIndex(ticket => ticket.id === ticketId);
  if (ticketIndex === -1) {
    throw new Error(`Ticket type with ID ${ticketId} not found`);
  }
  ticketTypes.splice(ticketIndex, 1);
  return true;
};

// ----------------- Cart & Order API -----------------

// Add tickets to cart (simulated, returns cart object)
export const addToCart = async (userId, ticketTypeId, quantity) => {
  await simulateDelay();
  
  // Find the ticket type
  const ticketType = findById(ticketTypes, ticketTypeId);
  if (!ticketType) {
    throw new Error(`Ticket type with ID ${ticketTypeId} not found`);
  }
  
  // Check availability
  if (ticketType.quantitySold + quantity > ticketType.quantity) {
    throw new Error('Not enough tickets available');
  }
  
  // Create cart item (simplified)
  const cartItem = {
    id: `cart-item-${Date.now()}`,
    ticketTypeId,
    quantity,
    unitPrice: ticketType.price,
    totalPrice: ticketType.price * quantity
  };
  
  // Return simulated cart
  return {
    userId,
    items: [cartItem],
    subtotal: cartItem.totalPrice,
    tax: cartItem.totalPrice * 0.0875, // 8.75% tax for example
    serviceFee: cartItem.totalPrice * 0.05, // 5% service fee
    total: cartItem.totalPrice * 1.1375, // Subtotal + tax + fee
    expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 min expiry
  };
};

// Create an order from cart
export const createOrder = async (userId, cartData) => {
  await simulateDelay();
  
  // Create a new order
  const newOrder = {
    id: `order-${Date.now()}`,
    userId,
    items: cartData.items,
    subtotal: cartData.subtotal,
    tax: cartData.tax,
    serviceFee: cartData.serviceFee,
    total: cartData.total,
    promoCode: cartData.promoCode || null,
    discount: cartData.discount || 0,
    status: 'pending',
    paymentIntentId: `pi_${Date.now()}`,
    createdAt: new Date().toISOString()
  };
  
  orders.push(newOrder);
  return clone(newOrder);
};

// Confirm order payment (simulated)
export const confirmOrderPayment = async (orderId) => {
  await simulateDelay();
  
  const orderIndex = orders.findIndex(order => order.id === orderId);
  if (orderIndex === -1) {
    throw new Error(`Order with ID ${orderId} not found`);
  }
  
  // Update order status
  orders[orderIndex].status = 'completed';
  
  // Generate tickets for the order
  const order = orders[orderIndex];
  const newTickets = [];
  
  for (const item of order.items) {
    for (let i = 0; i < item.quantity; i++) {
      const ticket = {
        id: `ticket-instance-${Date.now()}-${i}`,
        orderId,
        eventId: ticketTypes.find(t => t.id === item.ticketTypeId).eventId,
        ticketTypeId: item.ticketTypeId,
        userId: order.userId,
        status: 'active',
        qrCode: `data:image/png;base64,iVBORW0KGgoAAAANSUhEUgA...${Date.now()}`,
        barcode: `${Date.now()}${i}`,
        isCheckedIn: false,
        checkedInAt: null
      };
      
      tickets.push(ticket);
      newTickets.push(ticket);
      
      // Update the ticket type quantity sold
      const ticketTypeIndex = ticketTypes.findIndex(t => t.id === item.ticketTypeId);
      ticketTypes[ticketTypeIndex].quantitySold += 1;
    }
  }
  
  return {
    order: clone(orders[orderIndex]),
    tickets: clone(newTickets)
  };
};

// ----------------- User Tickets API -----------------

// Get user's tickets
export const fetchUserTickets = async (userId) => {
  await simulateDelay();
  const userTickets = tickets.filter(ticket => ticket.userId === userId);
  
  // Enrich with event and ticket type data
  const enrichedTickets = userTickets.map(ticket => {
    const event = findById(events, ticket.eventId);
    const ticketType = findById(ticketTypes, ticket.ticketTypeId);
    
    return {
      ...ticket,
      event: {
        id: event.id,
        title: event.title,
        startDate: event.startDate,
        location: event.location,
        isVirtual: event.isVirtual
      },
      ticketType: {
        name: ticketType.name,
        price: ticketType.price
      }
    };
  });
  
  return clone(enrichedTickets);
};

// ----------------- Promo Codes API -----------------

// Validate and apply promo code
export const validatePromoCode = async (code, eventId) => {
  await simulateDelay();
  
  const promoCode = promoCodes.find(
    promo => 
      promo.code === code && 
      promo.eventId === eventId &&
      new Date(promo.validFrom) <= new Date() &&
      new Date(promo.validTo) >= new Date() &&
      promo.usedCount < promo.maxUses
  );
  
  if (!promoCode) {
    throw new Error('Invalid or expired promo code');
  }
  
  return clone(promoCode);
};

// Apply promo code to cart
export const applyPromoCodeToCart = async (cart, promoCode) => {
  await simulateDelay();
  
  let discount = 0;
  
  if (promoCode.discountType === 'percentage') {
    discount = cart.subtotal * (promoCode.discountValue / 100);
  } else {
    discount = promoCode.discountValue;
  }
  
  // Make sure discount doesn't exceed subtotal
  discount = Math.min(discount, cart.subtotal);
  
  const updatedCart = {
    ...cart,
    promoCodeId: promoCode.id,
    discount,
    total: cart.subtotal + cart.tax + cart.serviceFee - discount
  };
  
  return updatedCart;
};