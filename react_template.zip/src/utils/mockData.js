// Mock data for the Eventverse application
// This simulates data that would typically come from a backend API

// Sample users data
export const users = [
  {
    id: 'user-1',
    email: 'organizer@example.com',
    firstName: 'John',
    lastName: 'Doe',
    role: 'organizer',
    profileImage: '/assets/images/profile-1.jpg',
    createdAt: '2023-01-15T10:30:00Z'
  },
  {
    id: 'user-2',
    email: 'participant@example.com',
    firstName: 'Jane',
    lastName: 'Smith',
    role: 'participant',
    profileImage: '/assets/images/profile-2.jpg',
    createdAt: '2023-02-20T14:45:00Z'
  }
];

// Sample organizer profiles
export const organizerProfiles = [
  {
    userId: 'user-1',
    organizationName: 'Tech Events Inc.',
    description: 'We host cutting-edge technology events and conferences.',
    website: 'https://techevents.example.com',
    socialLinks: ['https://twitter.com/techevents', 'https://linkedin.com/company/techevents'],
    phoneNumber: '+1234567890'
  }
];

// Sample participant profiles
export const participantProfiles = [
  {
    userId: 'user-2',
    interests: ['music', 'technology', 'education'],
    preferences: ['weekend events', 'online events'],
    location: {
      city: 'San Francisco',
      state: 'CA',
      country: 'USA'
    }
  }
];

// Sample event data
export const events = [
  {
    id: 'event-1',
    organizerId: 'user-1',
    title: 'Tech Conference 2023',
    description: 'A three-day conference featuring the latest innovations in technology, with workshops, keynote speakers, and networking opportunities.',
    category: 'Technology',
    startDate: '2023-09-15T09:00:00Z',
    endDate: '2023-09-17T18:00:00Z',
    status: 'published',
    location: {
      address: '123 Innovation Street',
      city: 'San Francisco',
      state: 'CA',
      country: 'USA',
      postalCode: '94105',
      latitude: 37.7749,
      longitude: -122.4194
    },
    isVirtual: false,
    virtualEventUrl: null,
    tags: ['technology', 'innovation', 'networking'],
    maxAttendees: 500,
    media: [
      {
        id: 'media-1',
        type: 'image',
        url: '/assets/images/events/tech-conf.jpg',
        thumbnailUrl: '/assets/images/events/thumbnails/tech-conf.jpg',
        order: 1
      },
      {
        id: 'media-2',
        type: 'video',
        url: '/assets/videos/tech-conf-promo.mp4',
        thumbnailUrl: '/assets/images/events/thumbnails/tech-conf-video.jpg',
        order: 2
      }
    ],
    createdAt: '2023-05-10T14:30:00Z',
    updatedAt: '2023-05-10T14:30:00Z',
    isFeatured: true
  },
  {
    id: 'event-2',
    organizerId: 'user-1',
    title: 'Music Festival 2023',
    description: 'Join us for an unforgettable weekend of live music performances across multiple stages, featuring top artists and emerging talent.',
    category: 'Music',
    startDate: '2023-07-20T16:00:00Z',
    endDate: '2023-07-22T23:59:00Z',
    status: 'published',
    location: {
      address: '456 Festival Grounds',
      city: 'Los Angeles',
      state: 'CA',
      country: 'USA',
      postalCode: '90001',
      latitude: 34.0522,
      longitude: -118.2437
    },
    isVirtual: false,
    virtualEventUrl: null,
    tags: ['music', 'festival', 'live entertainment'],
    maxAttendees: 2000,
    media: [
      {
        id: 'media-3',
        type: 'image',
        url: '/assets/images/events/music-fest.jpg',
        thumbnailUrl: '/assets/images/events/thumbnails/music-fest.jpg',
        order: 1
      }
    ],
    createdAt: '2023-04-15T10:20:00Z',
    updatedAt: '2023-04-15T10:20:00Z',
    isFeatured: true
  },
  {
    id: 'event-3',
    organizerId: 'user-1',
    title: 'Business Leadership Summit',
    description: 'A premier event for executives and business leaders to discuss strategies, innovations, and the future of business.',
    category: 'Business',
    startDate: '2023-08-05T08:00:00Z',
    endDate: '2023-08-06T17:00:00Z',
    status: 'published',
    location: {
      address: '789 Corporate Tower',
      city: 'New York',
      state: 'NY',
      country: 'USA',
      postalCode: '10001',
      latitude: 40.7128,
      longitude: -74.0060
    },
    isVirtual: false,
    virtualEventUrl: null,
    tags: ['business', 'leadership', 'networking'],
    maxAttendees: 300,
    media: [
      {
        id: 'media-4',
        type: 'image',
        url: '/assets/images/events/business-summit.jpg',
        thumbnailUrl: '/assets/images/events/thumbnails/business-summit.jpg',
        order: 1
      }
    ],
    createdAt: '2023-06-01T09:15:00Z',
    updatedAt: '2023-06-01T09:15:00Z',
    isFeatured: false
  },
  {
    id: 'event-4',
    organizerId: 'user-1',
    title: 'Online Web Development Workshop',
    description: 'Learn the fundamentals of web development in this hands-on virtual workshop. Perfect for beginners looking to start their coding journey.',
    category: 'Education',
    startDate: '2023-07-10T16:00:00Z',
    endDate: '2023-07-10T19:00:00Z',
    status: 'published',
    location: null,
    isVirtual: true,
    virtualEventUrl: 'https://meet.example.com/webdev-workshop',
    tags: ['education', 'web development', 'online learning'],
    maxAttendees: 100,
    media: [
      {
        id: 'media-5',
        type: 'image',
        url: '/assets/images/events/webdev-workshop.jpg',
        thumbnailUrl: '/assets/images/events/thumbnails/webdev-workshop.jpg',
        order: 1
      }
    ],
    createdAt: '2023-06-15T11:20:00Z',
    updatedAt: '2023-06-15T11:20:00Z',
    isFeatured: false
  },
  {
    id: 'event-5',
    organizerId: 'user-1',
    title: 'Charity Gala Dinner',
    description: 'An elegant evening of fine dining and entertainment to raise funds for community education projects.',
    category: 'Charity',
    startDate: '2023-09-30T18:00:00Z',
    endDate: '2023-09-30T23:00:00Z',
    status: 'published',
    location: {
      address: '101 Luxury Hotel',
      city: 'Chicago',
      state: 'IL',
      country: 'USA',
      postalCode: '60601',
      latitude: 41.8781,
      longitude: -87.6298
    },
    isVirtual: false,
    virtualEventUrl: null,
    tags: ['charity', 'fundraising', 'gala'],
    maxAttendees: 200,
    media: [
      {
        id: 'media-6',
        type: 'image',
        url: '/assets/images/events/charity-gala.jpg',
        thumbnailUrl: '/assets/images/events/thumbnails/charity-gala.jpg',
        order: 1
      }
    ],
    createdAt: '2023-07-05T16:45:00Z',
    updatedAt: '2023-07-05T16:45:00Z',
    isFeatured: true
  }
];

// Sample ticket types
export const ticketTypes = [
  {
    id: 'ticket-1',
    eventId: 'event-1',
    name: 'Early Bird',
    description: 'Limited early bird tickets at a discounted price.',
    price: 199.99,
    quantity: 100,
    quantitySold: 87,
    salesStartDate: '2023-05-15T00:00:00Z',
    salesEndDate: '2023-06-15T23:59:59Z',
    isActive: false
  },
  {
    id: 'ticket-2',
    eventId: 'event-1',
    name: 'Regular',
    description: 'Standard admission ticket.',
    price: 249.99,
    quantity: 300,
    quantitySold: 142,
    salesStartDate: '2023-06-16T00:00:00Z',
    salesEndDate: '2023-09-14T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-3',
    eventId: 'event-1',
    name: 'VIP',
    description: 'VIP access with exclusive networking session and preferred seating.',
    price: 399.99,
    quantity: 50,
    quantitySold: 28,
    salesStartDate: '2023-05-15T00:00:00Z',
    salesEndDate: '2023-09-14T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-4',
    eventId: 'event-2',
    name: 'General Admission',
    description: 'Three-day pass for all performances.',
    price: 150.00,
    quantity: 1500,
    quantitySold: 876,
    salesStartDate: '2023-04-20T00:00:00Z',
    salesEndDate: '2023-07-19T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-5',
    eventId: 'event-2',
    name: 'VIP Pass',
    description: 'VIP access including backstage tours and artist meet & greets.',
    price: 350.00,
    quantity: 200,
    quantitySold: 130,
    salesStartDate: '2023-04-20T00:00:00Z',
    salesEndDate: '2023-07-19T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-6',
    eventId: 'event-3',
    name: 'Standard',
    description: 'Standard admission for all sessions.',
    price: 499.99,
    quantity: 250,
    quantitySold: 98,
    salesStartDate: '2023-06-05T00:00:00Z',
    salesEndDate: '2023-08-04T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-7',
    eventId: 'event-4',
    name: 'Workshop Access',
    description: 'Full access to the online workshop and materials.',
    price: 49.99,
    quantity: 100,
    quantitySold: 42,
    salesStartDate: '2023-06-20T00:00:00Z',
    salesEndDate: '2023-07-09T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-8',
    eventId: 'event-5',
    name: 'Individual Seat',
    description: 'Single seat at the gala dinner.',
    price: 175.00,
    quantity: 150,
    quantitySold: 62,
    salesStartDate: '2023-07-15T00:00:00Z',
    salesEndDate: '2023-09-29T23:59:59Z',
    isActive: true
  },
  {
    id: 'ticket-9',
    eventId: 'event-5',
    name: 'Table of 8',
    description: 'Reserved table for 8 guests.',
    price: 1300.00,
    quantity: 20,
    quantitySold: 8,
    salesStartDate: '2023-07-15T00:00:00Z',
    salesEndDate: '2023-09-29T23:59:59Z',
    isActive: true
  }
];

// Sample promo codes
export const promoCodes = [
  {
    id: 'promo-1',
    eventId: 'event-1',
    code: 'TECH10',
    discountType: 'percentage',
    discountValue: 10,
    validFrom: '2023-06-01T00:00:00Z',
    validTo: '2023-07-01T23:59:59Z',
    maxUses: 100,
    usedCount: 37
  },
  {
    id: 'promo-2',
    eventId: 'event-2',
    code: 'MUSIC15',
    discountType: 'percentage',
    discountValue: 15,
    validFrom: '2023-05-01T00:00:00Z',
    validTo: '2023-05-31T23:59:59Z',
    maxUses: 200,
    usedCount: 183
  }
];

// Sample orders
export const orders = [
  {
    id: 'order-1',
    userId: 'user-2',
    items: [
      {
        id: 'item-1',
        ticketTypeId: 'ticket-2',
        quantity: 2,
        unitPrice: 249.99,
        totalPrice: 499.98
      }
    ],
    subtotal: 499.98,
    tax: 43.75,
    serviceFee: 25.00,
    total: 568.73,
    promoCode: null,
    discount: 0,
    status: 'completed',
    paymentIntentId: 'pi_1234567890',
    createdAt: '2023-06-20T15:40:22Z'
  }
];

// Sample tickets
export const tickets = [
  {
    id: 'ticket-instance-1',
    orderId: 'order-1',
    eventId: 'event-1',
    ticketTypeId: 'ticket-2',
    userId: 'user-2',
    status: 'active',
    qrCode: 'data:image/png;base64,iVBORW0KGgoAAAANSUhEUgA...',
    barcode: '9876543210',
    isCheckedIn: false,
    checkedInAt: null
  },
  {
    id: 'ticket-instance-2',
    orderId: 'order-1',
    eventId: 'event-1',
    ticketTypeId: 'ticket-2',
    userId: 'user-2',
    status: 'active',
    qrCode: 'data:image/png;base64,iVBORW0KGgoAAAANSUhEUgA...',
    barcode: '9876543211',
    isCheckedIn: false,
    checkedInAt: null
  }
];

// Get event categories
export const getEventCategories = () => {
  const categories = [...new Set(events.map(event => event.category))];
  return categories.sort();
};