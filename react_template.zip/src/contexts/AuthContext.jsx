import { createContext, useContext, useState, useEffect } from 'react';

// Create the auth context
const AuthContext = createContext();

// Custom hook to use the auth context
export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Check if user is already logged in via local storage on component mount
  useEffect(() => {
    const user = localStorage.getItem('eventverse_user');
    if (user) {
      setCurrentUser(JSON.parse(user));
    }
    setLoading(false);
  }, []);

  // Register function
  const register = async (email, password, firstName, lastName, role) => {
    try {
      setError('');
      // This would be replaced with actual API call in production
      // For now, simulate a successful registration
      const userData = {
        id: `user-${Date.now()}`,
        email,
        firstName,
        lastName,
        role,
        createdAt: new Date().toISOString()
      };
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Save to localStorage for persistence
      localStorage.setItem('eventverse_user', JSON.stringify(userData));
      setCurrentUser(userData);
      return userData;
    } catch (err) {
      setError('Failed to create an account: ' + err.message);
      throw err;
    }
  };

  // Login function
  const login = async (email, password) => {
    try {
      setError('');
      // This would be replaced with actual API call in production
      // For demo, we'll accept any email/password and create a mock user
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      const role = email.includes('organizer') ? 'organizer' : 'participant';
      const firstName = email.split('@')[0];
      
      const userData = {
        id: `user-${Date.now()}`,
        email,
        firstName,
        lastName: 'User',
        role,
        createdAt: new Date().toISOString()
      };
      
      // Save to localStorage for persistence
      localStorage.setItem('eventverse_user', JSON.stringify(userData));
      setCurrentUser(userData);
      return userData;
    } catch (err) {
      setError('Failed to login: ' + err.message);
      throw err;
    }
  };

  // Logout function
  const logout = async () => {
    try {
      // Clear user data from localStorage
      localStorage.removeItem('eventverse_user');
      setCurrentUser(null);
    } catch (err) {
      setError('Failed to logout: ' + err.message);
      throw err;
    }
  };

  // Update profile function
  const updateProfile = async (userData) => {
    try {
      setError('');
      // This would be replaced with actual API call in production
      
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Update the current user with new data
      const updatedUser = { ...currentUser, ...userData };
      
      // Save to localStorage
      localStorage.setItem('eventverse_user', JSON.stringify(updatedUser));
      setCurrentUser(updatedUser);
      return updatedUser;
    } catch (err) {
      setError('Failed to update profile: ' + err.message);
      throw err;
    }
  };

  // Reset password function (placeholder)
  const resetPassword = async (email) => {
    try {
      setError('');
      // Simulate API delay
      await new Promise(resolve => setTimeout(resolve, 800));
      return true;
    } catch (err) {
      setError('Failed to reset password: ' + err.message);
      throw err;
    }
  };

  const value = {
    currentUser,
    error,
    login,
    register,
    logout,
    updateProfile,
    resetPassword,
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}