import { createContext, useContext, useState, useEffect } from 'react';
import { fetchEvents, fetchEvent, createEvent, updateEvent, deleteEvent } from '../utils/api';

// Create the events context
const EventsContext = createContext();

// Custom hook to use the events context
export function useEvents() {
  return useContext(EventsContext);
}

export function EventsProvider({ children }) {
  const [events, setEvents] = useState([]);
  const [featuredEvents, setFeaturedEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Fetch all events on component mount
  useEffect(() => {
    const loadEvents = async () => {
      try {
        setLoading(true);
        setError('');
        
        // Fetch events from API (mock)
        const allEvents = await fetchEvents();
        setEvents(allEvents);
        
        // Filter for featured events (e.g., based on popularity or promotion status)
        const featured = allEvents.filter(event => event.isFeatured);
        setFeaturedEvents(featured);
      } catch (err) {
        setError('Failed to load events: ' + err.message);
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    
    loadEvents();
  }, []);

  // Get a specific event by ID
  const getEvent = async (eventId) => {
    try {
      setError('');
      return await fetchEvent(eventId);
    } catch (err) {
      setError('Failed to get event details: ' + err.message);
      throw err;
    }
  };

  // Add a new event
  const addEvent = async (eventData) => {
    try {
      setError('');
      const newEvent = await createEvent(eventData);
      setEvents(prevEvents => [...prevEvents, newEvent]);
      return newEvent;
    } catch (err) {
      setError('Failed to create event: ' + err.message);
      throw err;
    }
  };

  // Update an existing event
  const editEvent = async (eventId, eventData) => {
    try {
      setError('');
      const updatedEvent = await updateEvent(eventId, eventData);
      setEvents(prevEvents => 
        prevEvents.map(event => 
          event.id === eventId ? updatedEvent : event
        )
      );
      return updatedEvent;
    } catch (err) {
      setError('Failed to update event: ' + err.message);
      throw err;
    }
  };

  // Delete an event
  const removeEvent = async (eventId) => {
    try {
      setError('');
      await deleteEvent(eventId);
      setEvents(prevEvents => 
        prevEvents.filter(event => event.id !== eventId)
      );
    } catch (err) {
      setError('Failed to delete event: ' + err.message);
      throw err;
    }
  };

  // Search events by keyword
  const searchEvents = (keyword) => {
    if (!keyword) return events;
    
    const lowercasedKeyword = keyword.toLowerCase();
    return events.filter(event => {
      return (
        event.title.toLowerCase().includes(lowercasedKeyword) ||
        event.description.toLowerCase().includes(lowercasedKeyword) ||
        event.category.toLowerCase().includes(lowercasedKeyword) ||
        event.location.city.toLowerCase().includes(lowercasedKeyword)
      );
    });
  };
  
  // Filter events by category
  const filterEventsByCategory = (category) => {
    if (!category) return events;
    return events.filter(event => event.category === category);
  };

  // Get events by organizer ID
  const getEventsByOrganizer = (organizerId) => {
    return events.filter(event => event.organizerId === organizerId);
  };

  const value = {
    events,
    featuredEvents,
    loading,
    error,
    getEvent,
    addEvent,
    editEvent,
    removeEvent,
    searchEvents,
    filterEventsByCategory,
    getEventsByOrganizer
  };

  return (
    <EventsContext.Provider value={value}>
      {children}
    </EventsContext.Provider>
  );
}